package Gestion_abstract;



public class Main {
	public static void main(String[] args) {

		EmployeFixe employeFixe = new EmployeFixe("yassine", 100);
		employeFixe.showSaliare();
		
		EmployeCommission employeCommission = new EmployeCommission("salwa", 100, 10, 20);
		employeCommission.showSaliare();
		
		EmployeHoraire employeHoraire = new EmployeHoraire("yassine", 100, 10, 10);
		employeHoraire.showSaliare();
		
		
		/*EmployeFixe employeFixe = new EmployeFixe(100, 100);
		employeFixe.afficher();*/
	}

}
