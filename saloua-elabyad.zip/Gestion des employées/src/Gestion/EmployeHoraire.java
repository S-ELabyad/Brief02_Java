package Gestion;


public class EmployeHoraire extends Employe {


	private double tauxHoraire;
	private double heiresPrestees;

	EmployeHoraire(String nom, double salaire, double tauxHoraire, double heiresPrestees) {
		super(nom, salaire);
		this.tauxHoraire = tauxHoraire;
		this.heiresPrestees = heiresPrestees;
	}

	public double calculerSalaire() {
		return this.tauxHoraire * this.heiresPrestees;
	}

	public void showSaliare() {
		System.out.println("Bonjor " + getNom() + " salaire EmployeHoraire est: " + calculerSalaire() + " est votre salair est: " + getSalaire());
	}
}
