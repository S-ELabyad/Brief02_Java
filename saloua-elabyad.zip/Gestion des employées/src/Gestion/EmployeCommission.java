package Gestion;



public class EmployeCommission  extends Employe{
	
	private double ventes;
	private double commission;

	EmployeCommission(String nom, double salaire, double ventes, double commission) {
		super(nom, salaire);
		this.ventes = ventes;
		this.commission = commission;
	}

	public double calculerSalaire() {
		return getSalaire() + this.ventes * this.commission;
	}

	public void showSaliare() {
		System.out.println("Bonjor " + getNom() + " salaire EmployeCommission est: " + calculerSalaire());
	}

	

}
