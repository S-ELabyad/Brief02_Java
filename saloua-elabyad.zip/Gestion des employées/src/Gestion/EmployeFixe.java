package Gestion;

/*import java.util.Scanner;*/

public class EmployeFixe extends Employe {
	

	EmployeFixe( String nom ,double salaire) {
		super(nom, salaire);
	}

	public double calculerSalaire() {
		return getSalaire();
	}

	public void showSaliare() {
		System.out.println("Bonjor " + getNom() + " salaire EmployeFixe est: " + calculerSalaire());
	}
	
	
	
	
	
	
	
	
	/*public void afficher() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter votre salaire");
		setSalaire(sc.nextDouble());
		if(getSalaireMensuel()==getSalaire()) {
			
			System.out.println("votre salaire est " +getSalaireMensuel());
			}
		else {
			  System.out.println("eror");
		}
		sc.close();
		}*/
	
}
